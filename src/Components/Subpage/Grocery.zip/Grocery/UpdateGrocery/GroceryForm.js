import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function GroceryCard({ selectedGrocery, setSelectedGrocery }) {
    const [categories, setCategories] = useState([]);
    const [newCategory, setNewCategory] = useState('');
    const [message, setMessage] = useState('');
    const [groceryData, setGroceryData] = useState({
        name: '',
        totalCount: '',
        unit: 'Kg',
        expiryDate: '',
        warningLimit: '',
        price: '',
        vat: '',
        image: null,
        category: ''
    });

    useEffect(() => {
        fetchCategories();
    }, []);

    useEffect(() => {
        if (selectedGrocery) {
            console.log("Selected Grocery:", selectedGrocery);
            setGroceryData(selectedGrocery);
        }
    }, [selectedGrocery]);

    const fetchCategories = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/grocerycategories');
            setCategories(response.data);
        } catch (error) {
            console.error('Error fetching categories:', error);
            setMessage('Error fetching categories');
        }
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => {
                setGroceryData({ ...groceryData, image: reader.result.split(',')[1] });
            };
        }
    };

    const handleAddGrocery = async () => {
        if (!groceryData.name || !groceryData.totalCount || !groceryData.expiryDate || !groceryData.price || !groceryData.vat || !groceryData.category) {
            alert('Please fill all required fields');
            return;
        }

        const selectedCategory = categories.find(cat => cat._id === groceryData.category);
        const categoryName = selectedCategory ? selectedCategory.name : '';

        try {
            await axios.post('http://localhost:5000/api/groceries', {
                ...groceryData,
                category: categoryName
            });

            alert('Grocery added successfully!');
            resetForm();
        } catch (error) {
            console.error('Error adding grocery:', error.response ? error.response.data : error.message);
            setMessage('Error adding grocery');
        }
    };

    const handleUpdateGrocery = async () => {
        if (!groceryData._id) {
            alert('No grocery item selected for update.');
            return;
        }

        try {
            await axios.put(`http://localhost:5000/api/groceries/${groceryData._id}`, groceryData);
            alert('Grocery updated successfully!');
            resetForm();
        } catch (error) {
            console.error('Error updating grocery:', error.response ? error.response.data : error.message);
            setMessage('Error updating grocery');
        }
    };

    const resetForm = () => {
        setGroceryData({
            name: '',
            totalCount: '',
            unit: 'Kg',
            expiryDate: '',
            warningLimit: '',
            price: '',
            vat: '',
            image: null,
            category: ''
        });
        setSelectedGrocery(null);
    };

    return (
        <div className="flex w-[450px] h-full">
            {/* Grocery Form */}
            <div className="max-w-md p-4 h-full ml-12 mt-4 bg-white shadow-lg rounded-2xl border">
                {message && (
                    <div className={`p-2 mb-4 ${message.includes('Error') ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'} rounded`}>
                        {message}
                    </div>
                )}

                <h2 className="text-2xl font-bold text-center mb-4">
                    {selectedGrocery ? "Edit Grocery" : "Update Grocery"}
                </h2>

                <div className="space-y-3">
                    <input type="text" placeholder="Enter Grocery" className="w-full p-2 border rounded"
                        value={groceryData.name} onChange={(e) => setGroceryData({ ...groceryData, name: e.target.value })} />

                    <div className="flex space-x-2">
                        <input type="number" placeholder="Enter Total Count" className="w-2/3 p-2 border rounded"
                            value={groceryData.totalCount} onChange={(e) => setGroceryData({ ...groceryData, totalCount: e.target.value })} />
                        <select className="w-1/3 p-2 border rounded"
                            value={groceryData.unit} onChange={(e) => setGroceryData({ ...groceryData, unit: e.target.value })}>
                            <option value="Kg">Kg</option>
                            <option value="L">Liter</option>
                            <option value="Pieces">gram</option>
                        </select>
                    </div>

                    <input type="date" className="w-full p-2 border rounded"
                        value={groceryData.expiryDate} onChange={(e) => setGroceryData({ ...groceryData, expiryDate: e.target.value })} />

                    <input type="number" placeholder="Enter Warning Limitation" className="w-full p-2 border rounded"
                        value={groceryData.warningLimit} onChange={(e) => setGroceryData({ ...groceryData, warningLimit: e.target.value })} />

                    
                        <input type="number" placeholder="Enter Price" className="w-full p-2 border rounded"
                            value={groceryData.price} onChange={(e) => setGroceryData({ ...groceryData, price: e.target.value })} />
                        <input type="number" placeholder="Enter VAT" className="w-full p-2 border rounded"
                            value={groceryData.vat} onChange={(e) => setGroceryData({ ...groceryData, vat: e.target.value })} />
                    

                    <input type="file" className="w-full p-2 border rounded" onChange={handleImageChange} />

                    <select className="w-full p-2 border rounded"
                        value={groceryData.category} onChange={(e) => setGroceryData({ ...groceryData, category: e.target.value })}>
                        <option value="">Category</option>
                        {categories.map((category) => (
                            <option key={category._id} value={category._id}>{category.name}</option>
                        ))}
                    </select>

                    <button className="w-full bg-black text-white py-6 rounded-xl text-3xl font-bold" onClick={handleUpdateGrocery}>
                        Update Grocery
                    </button>
                
                </div>
            </div>
        </div>
    );
}

