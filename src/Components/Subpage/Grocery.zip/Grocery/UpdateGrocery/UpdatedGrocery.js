import React, { useState } from "react";
import GroceryList from "./GroceryList";
import GroceryForm from "./GroceryForm";

export default function UpdateGrocery() {
    const [selectedGrocery, setSelectedGrocery] = useState(null);

    const handleEditGrocery = (grocery) => {
        setSelectedGrocery(grocery);  // Set selected grocery when edit is clicked
    };

    return (
        <div className="flex justify-center items-start ">
            {/* Left: Grocery List/Table */}
            <div className="w-2/3 h-[600px]">
                <GroceryList onEditGrocery={handleEditGrocery} />
            </div>

            {/* Right: Grocery Form */}
            <div className="w-2/3 h-[600px]">
                <GroceryForm selectedGrocery={selectedGrocery} setSelectedGrocery={setSelectedGrocery} />
            </div>
        </div>
    );
}