import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { RxDashboard } from "react-icons/rx";
import { MdAdd } from "react-icons/md";

export default function GroceryCard() {
    const [categories, setCategories] = useState([]);
    const [newCategory, setNewCategory] = useState('');
    const [groceryData, setGroceryData] = useState({
        name: '',
        totalCount: '',
        unit: 'Kg',
        expiryDate: '',
        warningLimit: '',
        price: '',
        vat: '',
        image: null,
        category: ''
    });
    const [message, setMessage] = useState('');

    useEffect(() => {
        fetchCategories();
    }, []);

    const fetchCategories = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/grocerycategories');
            setCategories(response.data);
        } catch (error) {
            alert('Error fetching categories');
            console.error('Error fetching categories:', error);
        }
    };

    const handleAddCategory = async () => {
        if (!newCategory.trim()) {
            alert('Category name cannot be empty');
            return;
        }

        try {
            const response = await axios.post('http://localhost:5000/api/add-grocerycategory', { name: newCategory });
            setCategories([...categories, response.data]);
            setNewCategory('');
            setMessage('Category added successfully!');
        } catch (error) {
            alert('Error adding category');
            console.error('Error adding category:', error);
        }
    };

    const handleAddGrocery = async () => {
        if (!groceryData.name || !groceryData.totalCount || !groceryData.expiryDate || !groceryData.price || !groceryData.vat || !groceryData.category || !groceryData.image) {
            alert('Please fill all required fields');
            return;
        }
    
        const formData = new FormData();
        formData.append("name", groceryData.name);
        formData.append("totalCount", groceryData.totalCount);
        formData.append("unit", groceryData.unit);
        formData.append("expiryDate", groceryData.expiryDate);
        formData.append("warningLimit", groceryData.warningLimit);
        formData.append("price", groceryData.price);
        formData.append("vat", groceryData.vat);
        formData.append("category", groceryData.category); // Send category ID
        formData.append("image", groceryData.image);
    
        try {
            await axios.post("http://localhost:5000/api/add-groceries", formData, {
                headers: { "Content-Type": "multipart/form-data" },
            });
    
            alert("Grocery added successfully!");
            setGroceryData({
                name: "",
                totalCount: "",
                unit: "Kg",
                expiryDate: "",
                warningLimit: "",
                price: "",
                vat: "",
                image: null,
                category: "",
            });
        } catch (error) {
            alert("Error adding grocery");
            console.error("Error adding grocery:", error.response ? error.response.data : error.message);
        }
    };
    
    
    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setGroceryData({ ...groceryData, image: file });
    };
    
    

    return (
        <div className="max-w-md mx-auto p-4">
            {message && (
                <div className={`p-2 mb-4 ${message.includes('Error') ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'} rounded`}>
                    {message}
                </div>
            )}

            {/* Grocery Form */}
            <div className="bg-white shadow-lg rounded-2xl border p-4 mb-2">
                <h2 className="text-xl font-bold text-center mb-4">Add New Grocery</h2>
                <div className="space-y-3">
                    <input type="text" placeholder="Enter Grocery" className="w-full p-2 border rounded"
                        value={groceryData.name} onChange={(e) => setGroceryData({ ...groceryData, name: e.target.value })} />
                    
                    <div className="flex space-x-2">
                        <input type="number" placeholder="Enter Total Count" className="w-2/3 p-2 border rounded"
                            value={groceryData.totalCount} onChange={(e) => setGroceryData({ ...groceryData, totalCount: e.target.value })} />
                        <select className="w-1/3 p-2 border rounded"
                            value={groceryData.unit} onChange={(e) => setGroceryData({ ...groceryData, unit: e.target.value })}>
                            <option value="Kg">Kg</option>
                            <option value="L">Liter</option>
                            <option value="Pieces">gram</option>
                        </select>
                    </div>

                    <input type="date" className="w-full p-2 border rounded"
                        value={groceryData.expiryDate} onChange={(e) => setGroceryData({ ...groceryData, expiryDate: e.target.value })} />

                    <input type="number" placeholder="Enter Warning Limitation" className="w-full p-2 border rounded"
                        value={groceryData.warningLimit} onChange={(e) => setGroceryData({ ...groceryData, warningLimit: e.target.value })} />

                    <div className="flex space-x-2">
                        <input type="number" placeholder="Enter Price" className="w-1/2 p-2 border rounded"
                            value={groceryData.price} onChange={(e) => setGroceryData({ ...groceryData, price: e.target.value })} />
                        <input type="number" placeholder="Enter VAT" className="w-1/2 p-2 border rounded"
                            value={groceryData.vat} onChange={(e) => setGroceryData({ ...groceryData, vat: e.target.value })} />
                    </div>
                    <div className='flex space-x-2'>
                    <input type="file" className="w-full p-2 border rounded" onChange={handleImageChange} />
                    
                    <select className="w-full p-2 border rounded"
                        value={groceryData.category} onChange={(e) => setGroceryData({ ...groceryData, category: e.target.value })}>
                        <option value="">Category</option>
                        {categories.map((category) => (
                            <option key={category._id} value={category._id}>{category.name}</option>
                        ))}
                    </select>
                    </div>

                    <button className="w-full bg-black text-white py-2 rounded text-lg font-bold" onClick={handleAddGrocery}>
                        + ADD GROCERY
                    </button>
                </div>
            </div>

             {/* Add New Category Form */}
             <div className="bg-white shadow-lg rounded-2xl border p-4 ">
                <div className="flex items-center bg-red-500 rounded p-2">
                    {/* Input Field */}
                    <input
                        type="text"
                        placeholder="Enter New Category"
                        className="w-full bg-red-500 border-none text-white placeholder-white focus:outline-none"
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value)}
                    />
                    
                    {/* Icon */}
                    <span className="text-white text-xl mr-6">
                        <RxDashboard />
                    </span>
                </div>
                <button
                    className="w-full bg-black mt-2 text-white text-2xl py-4 rounded-lg flex items-center justify-center font-bold gap-2"
                    onClick={handleAddCategory}
                >
                    <MdAdd className="text-3xl" /> ADD CATEGORY
                </button>
            </div>
        </div>
    );
}































