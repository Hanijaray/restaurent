import React from "react";
import AddGroceryCard from "./AddGroceryCard";
import SetProduct from "./SetProduct";

export default function GroceryDashboard() {
    return (
        <div className="flex justify-center items-start">  {/* Added gap-4 for spacing */}
            {/* Left: SetProduct */}
            <div className=" h-[600px] flex">  
                <SetProduct />
            </div>

            {/* Right: AddGroceryCard */}
            <div className="w-1/3 h-[600px] flex">  
                <AddGroceryCard />
            </div>
        </div>
    );
}